function [Ax, Ay, Gx, Gy, Bx, By,Axc, Ayc, Gxc, Gyc, Bxc, Byc, vect_temps, delta_,delta_c, Dtheta_,Dtheta_c, deltaF_, deltaR_, DA_, Ff_, Fr_, Ffmax_, Frmax_, Vu, Vbeta,beta_] = Simulation(scenario, T_simu, Param, vitesse, braquage, tau)
    %% Caractéristiques véhicule  
    Param.L = Param.Lr + Param.Lf;

    %% Paramètre de simulation
    Param.tf = T_simu;
    Param.dt = 1/100;
    Param.Temps_ = (0:Param.dt:Param.tf)';
    vect_temps = Param.Temps_;
    Param.Lt = length(Param.Temps_);
    Param.AngleBraquage = braquage;
    Tc_beta = T_simu/5; % Temps pour atteindre l'angle de braquage maximum en secondes
    Tc_u = T_simu/2; % Temps pour atteindre la vitesse maximale en secondes
    Tc_freinage = T_simu/10;
    
    %% Variable d'entrée
    u_ = vitesse/3.6 * ones(Param.Lt, 1);
    beta_ = deg2rad(braquage)*ones(Param.Lt,1);
    
    %Défintion d'une vitesse limite
    ulim = 5/3.6 ;
    %% Initialisation des variables
    Vbeta = zeros(Param.Lt, 1);
    Vu = zeros(Param.Lt, 1);
    
    switch scenario
        case 1 
            % Initialisation des variables
            Vbeta = zeros(size(Param.Temps_));
            Vu = zeros(size(Param.Temps_));
            beta_ = deg2rad(braquage)*ones(Param.Lt,1);

            % Simulation du freinage brusque dans un virage
            for i = 1:Param.Lt
                %decay_factor = exp(-(Param.Temps_(i) - T_simu / 2) * tau);
                %beta_(i) = deg2rad(u_(i) * decay_factor * (Param.Temps_(i) / Tc_freinage) / sqrt(1 + (Param.Temps_(i) / Tc_freinage)^2));
                Vbeta(i) = beta_(i) * (Param.Temps_(i) / Tc_beta) / sqrt(1 + (Param.Temps_(i) / Tc_beta)^2);
            
            % Supposons que le freinage brusque est déclenché à un certain moment (par exemple, à mi-chemin)
                if Param.Temps_(i) <= T_simu / 2
                    Vu(i) = u_(i) * (Param.Temps_(i) / Tc_freinage) / sqrt(1 + (Param.Temps_(i) / Tc_freinage)^2);
                else
                    decay_factor = exp(-(Param.Temps_(i) - T_simu / 2) * tau);
                    Vu(i) = u_(i) * decay_factor * (Param.Temps_(i) / Tc_freinage) / sqrt(1 + (Param.Temps_(i) / Tc_freinage)^2);
                end
            end
        case 2 
                for i = 1:Param.Lt
                    Vbeta(i) = beta_(i) * (Param.Temps_(i) / Tc_beta) / sqrt(1 + (Param.Temps_(i) / Tc_beta)^2);
                    Vu(i) = u_(i) * (Param.Temps_(i) / Tc_u) / sqrt(1 + (Param.Temps_(i) / Tc_u)^2);
                end
        case 4
            vitesse_ms = vitesse/3.6;
            for i = 1:Param.Lt
                obstacle_detection_time = 2.0;
                arc_duration = 8.0;
                if Param.Temps_(i) <= obstacle_detection_time
                    Vu(i) = vitesse_ms;
                    Vbeta(i) = 0;
                elseif Param.Temps_(i) <= obstacle_detection_time + arc_duration
                    Vu(i) = vitesse_ms;
                    t = (Param.Temps_(i) - obstacle_detection_time) / arc_duration;
                    % Fonction sinusoïdale avec trois phases : gauche, droite, retour
                    Vbeta(i) = 0.15 * sin(3 * pi * t - pi/2);
                else
                    Vu(i) = vitesse_ms;
                    Vbeta(i) = 0;
                end
            end
    end

        %% Initialisation des variables
        theta_0 = 0;
        Dtheta_0 = 0;
        D2theta_0 = 0;
        delta_0 = (Param.Lr / (Param.Lr + Param.Lf))*Vbeta(1);
        Ddelta_0 = 0;
        deltaR_0 = 0;
        deltaF_0 = 0;
        deltaF_max = 5;
        deltaR_max = 5;
        da_0 = abs(deltaF_0 - deltaR_0);

        % Initialisation des variables de position
        Bx_0 = 0;
        By_0 = 0;
        Gx_0 = Bx_0 + Param.Lr * cos(theta_0 + delta_0);
        Gy_0 = By_0 + Param.Lr * sin(theta_0 + delta_0);
        Ax_0 = Bx_0 + (Param.Lr + Param.Lf) * cos(theta_0 + beta_(1) + delta_0);
        Ay_0 = By_0 + (Param.Lr + Param.Lf) * sin(theta_0 + beta_(1) + delta_0);
        % Initialisation des variables de vitesse en A, B et G selon x et y
        VBx_0 = Vu(1);
        VBy_0 = 0;
        VB_0 = Vu(1); % Norme de la vitesse sur la roue arrière
        VGx_0 = 0;
        VGy_0 = 0;
        VAx_0 = 0;
        VAy_0 = 0;
        % Initialisation des variables d'accélération en A, B et G selon x et y
        ABx_0 = 0;
        ABy_0 = 0;
        AGx_0 = 0;
        AGy_0 = 0;
        AG_0 = 0;
        AAx_0 = 0;
        AAy_0 = 0;
        %% Initialisation des variables d'états
        theta_ = zeros(Param.Lt,1);
        Dtheta_ = zeros(Param.Lt,1);
        D2theta_ = zeros(Param.Lt,1);
        theta_(1) = rad2deg(theta_0);
        Dtheta_(1) = rad2deg(Dtheta_0);
        D2theta_(1) = rad2deg(D2theta_0);
        delta_ = zeros(Param.Lt,1);
        Ddelta_ = zeros(Param.Lt,1);
        deltaR_ = zeros(Param.Lt,1);
        deltaF_ = zeros(Param.Lt,1);
        DA_ =  zeros(Param.Lt,1);
        Ddelta_(1) = rad2deg(Ddelta_0);
        delta_(1) = rad2deg(delta_0);
        DA_(1) = da_0;
        Ff_ = zeros(Param.Lt, 1);
        Fr_ = zeros(Param.Lt, 1);
        Ffmax_ = zeros(Param.Lt, 1);
        Frmax_ = zeros(Param.Lt, 1);
        R = zeros(Param.Lt, 1);
        Bx = zeros(Param.Lt, 1);
        By = zeros(Param.Lt, 1);
        Gx = zeros(Param.Lt, 1);
        Gy = zeros(Param.Lt, 1);
        Ax = zeros(Param.Lt, 1);
        Ay = zeros(Param.Lt, 1);
        Bx(1) = Bx_0;
        By(1) = By_0;
        Gx(1) = Gx_0;
        Gy(1) = Gy_0;
        Ax(1) = Ax_0;
        Ay(1) = Ay_0;
        VBx = zeros(Param.Lt, 1);
        VBy = zeros(Param.Lt, 1);
        VGx = zeros(Param.Lt, 1);
        VGy = zeros(Param.Lt, 1);
        VAx = zeros(Param.Lt, 1);
        VAy = zeros(Param.Lt, 1);
        VBx(1) = VBx_0 * 3.6; 
        VBy(1) = VBy_0 * 3.6;
        VGx(1) = VGx_0 * 3.6;
        VGy(1) = VGy_0 * 3.6;
        VAx(1) = VAx_0 * 3.6;
        VAy(1) = VAy_0 * 3.6;
        ABx = zeros(Param.Lt, 1);
        ABy = zeros(Param.Lt, 1);
        AGx = zeros(Param.Lt, 1);
        AGy = zeros(Param.Lt, 1);
        AAx = zeros(Param.Lt, 1);
        AAy = zeros(Param.Lt, 1);






        %% Initialisation des variables cinématiques
        theta_0c = 0;
        Dtheta_0c = 0;
        D2theta_0c = 0;
        delta_0c = (Param.Lr / (Param.Lr + Param.Lf))*Vbeta(1);
        Ddelta_0c = 0;
        deltaR_0c = 0;
        deltaF_0c = 0;
        deltaF_maxc = 5;
        deltaR_maxc = 5;
        da_0c = abs(deltaF_0c - deltaR_0c);

        % Initialisation des variables de position cinématique
        Bx_0c = 0;
        By_0c = 0;
        Gx_0c = Bx_0c + Param.Lr * cos(theta_0c + delta_0c);
        Gy_0c = By_0c + Param.Lr * sin(theta_0c + delta_0c);
        Ax_0c = Bx_0c + (Param.Lr + Param.Lf) * cos(theta_0c + beta_(1) + delta_0c);
        Ay_0c = By_0c + (Param.Lr + Param.Lf) * sin(theta_0c + beta_(1) + delta_0c);
        % Initialisation des variables de vitesse en A, B et G selon x et y
        % cinématique
        VBx_0c = Vu(1);
        VBy_0c = 0;
        VB_0c = Vu(1); % Norme de la vitesse sur la roue arrière
        VGx_0c = 0;
        VGy_0c= 0;
        VAx_0c = 0;
        VAy_0c = 0;
        % Initialisation des variables d'accélération en A, B et G selon x
        % et y cinématique
        ABx_0c = 0;
        ABy_0c = 0;
        AGx_0c = 0;
        AGy_0c = 0;
        AG_0c = 0;
        AAx_0c = 0;
        AAy_0c = 0;
        %% Initialisation des variables d'états cinématiques
        theta_c = zeros(Param.Lt,1);
        Dtheta_c = zeros(Param.Lt,1);
        D2theta_c = zeros(Param.Lt,1);
        theta_c(1) = rad2deg(theta_0);
        Dtheta_c(1) = rad2deg(Dtheta_0);
        D2theta_c(1) = rad2deg(D2theta_0);
        delta_c = zeros(Param.Lt,1);
        Ddelta_c = zeros(Param.Lt,1);
        deltaR_c = zeros(Param.Lt,1);
        deltaF_c = zeros(Param.Lt,1);
        DA_c =  zeros(Param.Lt,1);
        Ddelta_c(1) = rad2deg(Ddelta_0);
        delta_c(1) = rad2deg(delta_0);
        DA_c(1) = da_0;
        Ff_c = zeros(Param.Lt, 1);
        Fr_c = zeros(Param.Lt, 1);
        Ffmax_c = zeros(Param.Lt, 1);
        Frmax_c = zeros(Param.Lt, 1);
        Rc = zeros(Param.Lt, 1);
        Bxc = zeros(Param.Lt, 1);
        Byc = zeros(Param.Lt, 1);
        Gxc = zeros(Param.Lt, 1);
        Gyc = zeros(Param.Lt, 1);
        Axc = zeros(Param.Lt, 1);
        Ayc = zeros(Param.Lt, 1);
        Bxc(1) = Bx_0c;
        Byc(1) = By_0c;
        Gxc(1) = Gx_0c;
        Gyc(1) = Gy_0c;
        Axc(1) = Ax_0c;
        Ayc(1) = Ay_0c;
        VBxc = zeros(Param.Lt, 1);
        VByc = zeros(Param.Lt, 1);
        VGxc = zeros(Param.Lt, 1);
        VGyc = zeros(Param.Lt, 1);
        VAxc = zeros(Param.Lt, 1);
        VAyc = zeros(Param.Lt, 1);
        VBxc(1) = VBx_0c * 3.6; 
        VByc(1) = VBy_0c * 3.6;
        VGxc(1) = VGx_0c * 3.6;
        VGyc(1) = VGy_0c * 3.6;
        VAxc(1) = VAx_0c * 3.6;
        VAyc(1) = VAy_0c * 3.6;
        ABxc = zeros(Param.Lt, 1);
        AByc = zeros(Param.Lt, 1);
        AGxc = zeros(Param.Lt, 1);
        AGyc = zeros(Param.Lt, 1);
        AAxc = zeros(Param.Lt, 1);
        AAyc = zeros(Param.Lt, 1);


%% Boucle de simulation
for i = 2 : Param.Lt
    if Vu(i) <= ulim
        % Calcul des angles de lacet et de dérive globaux
        Dtheta_1 = Vu(i) * tan(Vbeta(i)) / (Param.Lr + Param.Lf);
        theta_1 = theta_0 + Param.dt * Dtheta_1;
        delta_1 = (Param.Lr / (Param.Lr + Param.Lf)) * Vbeta(i);
        Dtheta_(i) = Dtheta_1 * 180 / pi;
        theta_(i) = theta_1 * 180 / pi;
        delta_(i) = delta_1 * 180 / pi;
        % Calcul des vitesses
        VBx_1 = Vu(i);
        VBy_1 = 0;
        VGx_1 = Vu(i) / cos(delta_1);
        VGy_1 = Param.Lr * Dtheta_1 / sin(delta_1);
        VAx_1 = Vu(i) / cos(Vbeta(i));
        VAy_1 = (Param.Lr + Param.Lf) * Dtheta_1 / sin(Vbeta(i));
        VBx(i) = VBx_1 * 3.6;
        VBy(i) = VBy_1 * 3.6;
        VGx(i) = VGx_1 * 3.6;
        VGy(i) = VGy_1 * 3.6;
        VAx(i) = VAx_1 * 3.6;
        VAy(i) = VAy_1 * 3.6;
        % Calcul du rayon de courbure
        R_1 = Vu(i) / Dtheta_1;
        R(i) = R_1;
        R_0 = R_1;
        % Calcul des positions
        Bx_1 = Bx_0 + VBx_1 * cos(theta_1 + Vbeta(i)) * Param.dt;
        By_1 = By_0 + VBx_1 * sin(theta_1 + Vbeta(i)) * Param.dt;
        Gx_1 = Gx_0 + VGx_1 * cos(theta_1 + Vbeta(i)) * Param.dt;
        Gy_1 = Gy_0 + VGy_1 * sin(theta_1 + Vbeta(i)) * Param.dt;
        Ax_1 = Ax_0 + VAx_1 * cos(theta_1 + Vbeta(i) + deltaF_0) * Param.dt;
        Ay_1 = Ay_0 + VAy_1 * sin(theta_1 + Vbeta(i) + deltaF_0) * Param.dt;
        Bx(i) = Bx_1;
        By(i) = By_1;
        Gx(i) = Gx_1;
        Gy(i) = Gy_1;
        Ax(i) = Ax_1;
        Ay(i) = Ay_1;
        % Calcul des accélérations
        ABx_1 = (Vu(i) - Vu(i-1)) / Param.dt;
        ABy_1 = Vu(i) * Dtheta_1;
        AGx_1 = -Param.Lr * Dtheta_1^2 / sin(delta_1);
        AGy_1 = Vu(i) * Dtheta_1 / cos(delta_1);
        AAx_1 = -(Param.Lr + Param.Lf) * Dtheta_1^2 / sin(Vbeta(i));
        AAy_1 = Vu(i) * Dtheta_1 / cos(Vbeta(i));
        ABx(i) = ABx_1 / 9.81;
        ABy(i) = ABy_1 / 9.81;
        AGx(i) = AGx_1 / 9.81;
        AGy(i) = AGy_1 / 9.81;
        AAx(i) = AAx_1 / 9.81;
        AAy(i) = AAy_1 / 9.81;
        % Mise à jour des variables
        Dtheta_0 = Dtheta_1;
        theta_0 = theta_1;
        delta_0 = delta_1;
        Bx_0 = Bx_1;
        By_0 = By_1;
        Gx_0 = Gx_1;
        Gy_0 = Gy_1;
        Ax_0 = Ax_1;
        Ay_0 = Ay_1;
        VBx_0 = VBx_1;
        VBy_0 = VBy_1;
        VGx_0 = VGx_1;
        VGy_0 = VGy_1;
        VAx_0 = VAx_1;
        VAy_0 = VAy_1;
        ABx_0 = ABx_1;
        ABy_0 = ABy_1;
        AGx_0 = AGx_1;
        AGy_0 = AGy_1;
        AAx_0 = AAx_1;
        AAy_0 = AAy_1;





        % Calcul des angles de lacet et de dérive globaux cinématiques
        Dtheta_1 = Vu(i) * tan(Vbeta(i)) / (Param.Lr + Param.Lf);
        theta_1 = theta_0 + Param.dt * Dtheta_1;
        delta_1 = (Param.Lr / (Param.Lr + Param.Lf)) * Vbeta(i);
        Dtheta_c(i) = Dtheta_1 * 180 / pi;
        theta_c(i) = theta_1 * 180 / pi;
        delta_c(i) = delta_1 * 180 / pi;
        % Calcul des vitesses
        VBx_1 = Vu(i);
        VBy_1 = 0;
        VGx_1 = Vu(i) / cos(delta_1);
        VGy_1 = Param.Lr * Dtheta_1 / sin(delta_1);
        VAx_1 = Vu(i) / cos(Vbeta(i));
        VAy_1 = (Param.Lr + Param.Lf) * Dtheta_1 / sin(Vbeta(i));
        VBxc(i) = VBx_1 * 3.6;
        VByc(i) = VBy_1 * 3.6;
        VGxc(i) = VGx_1 * 3.6;
        VGyc(i) = VGy_1 * 3.6;
        VAxc(i) = VAx_1 * 3.6;
        VAyc(i) = VAy_1 * 3.6;
        % Calcul du rayon de courbure
        R_1 = Vu(i) / Dtheta_1;
        Rc(i) = R_1;
        R_0c = R_1;
        % Calcul des positions
        Bx_1 = Bx_0 + VBx_1 * cos(theta_1 + Vbeta(i)) * Param.dt;
        By_1 = By_0 + VBx_1 * sin(theta_1 + Vbeta(i)) * Param.dt;
        Gx_1 = Gx_0 + VGx_1 * cos(theta_1 + Vbeta(i)) * Param.dt;
        Gy_1 = Gy_0 + VGy_1 * sin(theta_1 + Vbeta(i)) * Param.dt;
        Ax_1 = Ax_0 + VAx_1 * cos(theta_1 + Vbeta(i) + deltaF_0) * Param.dt;
        Ay_1 = Ay_0 + VAy_1 * sin(theta_1 + Vbeta(i) + deltaF_0) * Param.dt;
        Bxc(i) = Bx_1;
        Byc(i) = By_1;
        Gxc(i) = Gx_1;
        Gyc(i) = Gy_1;
        Axc(i) = Ax_1;
        Ayc(i) = Ay_1;
        % Calcul des accélérations
        ABx_1 = (Vu(i) - Vu(i-1)) / Param.dt;
        ABy_1 = Vu(i) * Dtheta_1;
        AGx_1 = -Param.Lr * Dtheta_1^2 / sin(delta_1);
        AGy_1 = Vu(i) * Dtheta_1 / cos(delta_1);
        AAx_1 = -(Param.Lr + Param.Lf) * Dtheta_1^2 / sin(Vbeta(i));
        AAy_1 = Vu(i) * Dtheta_1 / cos(Vbeta(i));
        ABxc(i) = ABx_1 / 9.81;
        AByc(i) = ABy_1 / 9.81;
        AGxc(i) = AGx_1 / 9.81;
        AGyc(i) = AGy_1 / 9.81;
        AAxc(i) = AAx_1 / 9.81;
        AAyc(i) = AAy_1 / 9.81;
        % Mise à jour des variables
        Dtheta_0c = Dtheta_1;
        theta_0c = theta_1;
        delta_0c = delta_1;
        Bx_0c = Bx_1;
        By_0c = By_1;
        Gx_0c = Gx_1;
        Gy_0c = Gy_1;
        Ax_0c = Ax_1;
        Ay_0c = Ay_1;
        VBx_0c = VBx_1;
        VBy_0c = VBy_1;
        VGx_0c = VGx_1;
        VGy_0c = VGy_1;
        VAx_0c = VAx_1;
        VAy_0c = VAy_1;
        ABx_0c = ABx_1;
        ABy_0c = ABy_1;
        AGx_0c = AGx_1;
        AGy_0c = AGy_1;
        AAx_0c = AAx_1;
        AAy_0c = AAy_1;
    else
    
        %Calcul des coeffecients de la matrice
        a_11 = -(Param.Cf*Param.Lf^2 + Param.Cr*Param.Lr^2)/(Param.Iz*Vu(i));
        a_12 = (Param.Cr*Param.Lr-Param.Cf*Param.Lf)/Param.Iz;
        a_21 = ((Param.Lr*Param.Cr - Param.Lf*Param.Cf)/((Vu(i)^2)*Param.m))-1;
        a_22 = -((Param.Cr+Param.Cf)/(Param.m*Vu(i)));
        b_11 = (Param.Lf*Param.Cf)/Param.Iz;
        b_21 = Param.Cf/(Param.m*Vu(i));
        %% Calcul des angles
        D2theta_1 = (a_11)*Dtheta_0 + (a_12)*delta_0 + (b_11)*Vbeta(i);
        Dtheta_1 = Dtheta_0 + Param.dt*D2theta_1;
        theta_1 = theta_0 + Param.dt*Dtheta_1;
        Ddelta_1 = (a_21)* Dtheta_0 + (a_22)*delta_0 + (b_21)*Vbeta(i);
        delta_1 = delta_0 + Param.dt*Ddelta_1;
        deltaF_1 = delta_1 - Vbeta(i) + (Param.Lf*Dtheta_1/Vu(i));
        deltaR_1 = delta_1 - (Param.Lr*Dtheta_1/Vu(i));
        Ff_1 = -Param.Cf * deltaF_1;
        Fr_1 = -Param.Cr * deltaR_1;
        if abs(deltaF_1) > (deltaF_max)* pi/180
            Ffmax_1 = - Param.Cf * deltaF_max * sign(deltaF_1) * pi/180;
        else
            Ffmax_1 = Ff_1;
        end
        if abs(deltaR_1) > (deltaR_max)* pi/180
            Frmax_1 = - Param.Cr * deltaR_max * sign(deltaR_1) * pi/180;
        else
            Frmax_1 = Fr_1;
    end

    % Calcul des positions des roues Avant (A) et Arrière (B) et du Centre de gravité (G)
    Bx_1 = Bx_0 + Vu(i) * Param.dt * cos(theta_1 + deltaR_1);
    By_1 = By_0 + Vu(i) * Param.dt * sin(theta_1 + deltaR_1);
    
    % Calcul des positions en A et G
    Gx_1 = Bx_0 + Param.Lr * cos(theta_1 + delta_1);
    Gy_1 = By_0 + Param.Lr * sin(theta_1 + delta_1);
    Ax_1 = Bx_0 + (Param.Lf + Param.Lr) * cos(theta_1 - deltaF_1);
    Ay_1 = By_0 + (Param.Lf + Param.Lr) * sin(theta_1 - deltaF_1);

    % Calcul des vitesses en A, B et G
    VGx_1 = Vu(i) * cos(delta_1);
    VGy_1 = Vu(i) * sin(delta_1);
    VAx_1 = (Vu(i) * cos(delta_1)) / (cos(deltaF_1 + Vbeta(i)));
    VAy_1 = (Vu(i) * sin(delta_1) + Param.Lf * Dtheta_1) / (sin(deltaF_1 + Vbeta(i)));
    VBx_1 = (Vu(i) * cos(delta_1)) / (cos(deltaR_1));
    VBy_1 = (Vu(i) * sin(delta_1) - Param.Lr * Dtheta_1) / (sin(deltaR_1));
    
    % Calcul des accélérations en A, B et G
    AGx_1 = (-Ff_1 * sin(Vbeta(i))) / Param.m;
    AGy_1 = (Fr_1 + Ff_1 * cos(Vbeta(i))) / Param.m;
    AG_1 = sqrt(AGx_1^2 + AGy_1^2);
    AAx_1 = (VAx_1 - VAx_0) / Param.dt;
    AAy_1 = (VAy_1 - VAy_0) / Param.dt;
    ABx_1 = (VBx_1 - VBx_0) / Param.dt;
    ABy_1 = (VBy_1 - VBy_0) / Param.dt;
    % Calcul du rayon de courbure
    VB_1 = sqrt(VBx_1^2 + VBy_1^2);
    R_1 = VB_1 / Dtheta_1;
    % Calcul de la différence entre les angles de dérive avant et arrière
    da_1 = abs(deltaF_1) - abs(deltaR_1);
    % Incorporation dans les vecteurs de sortie
    delta_(i) = rad2deg(delta_1);
    Ddelta_(i) = rad2deg(Ddelta_1);
    deltaR_(i) = rad2deg(deltaR_1);
    deltaF_(i) = rad2deg(deltaF_1);
    theta_(i) = rad2deg(theta_1);
    Dtheta_(i) = rad2deg(Dtheta_1);
    D2theta_(i) = rad2deg(D2theta_1);
    DA_(i) = da_1 * 180 / pi;
    Ff_(i) = Ff_1;
    Fr_(i) = Fr_1;
    Ffmax_(i) = Ffmax_1;
    Frmax_(i) = Frmax_1;
    Bx(i) = Bx_1;
    By(i) = By_1;
    Gx(i) = Gx_1;
    Gy(i) = Gy_1;
    Ax(i) = Ax_1;
    Ay(i) = Ay_1;
    VBx(i) = VBx_1 * 3.6;
    VBy(i) = VBy_1 * 3.6;
    VGx(i) = VGx_1 * 3.6;
    VGy(i) = VGy_1 * 3.6;
    VAx(i) = VAx_1 * 3.6;
    VAy(i) = VAy_1 * 3.6;
    ABx(i) = ABx_1 / 9.81;
    ABy(i) = ABy_1 / 9.81;
    AGx(i) = AGx_1 / 9.81;
    AGy(i) = AGy_1 / 9.81;
    AAx(i) = AAx_1 / 9.81;
    AAy(i) = AAy_1 / 9.81;
    R(i) = R_1;



    %Continuons le calcul cinématique pour les lols

    % Calcul des angles de lacet et de dérive globaux
    Dtheta_1c = Vu(i) * tan(Vbeta(i)) / (Param.Lr + Param.Lf);
    theta_1c = theta_0 + Param.dt * Dtheta_1c;
    delta_1c = (Param.Lr / (Param.Lr + Param.Lf)) * Vbeta(i);
    Dtheta_c(i) = Dtheta_1c * 180 / pi;
    theta_c(i) = theta_1c * 180 / pi;
    delta_c(i) = delta_1c * 180 / pi;
    % Calcul des vitesses
    VBx_1c = Vu(i);
    VBy_1c = 0;
    VGx_1c = Vu(i) / cos(delta_1c);
    VGy_1c = Param.Lr * Dtheta_1c / sin(delta_1c);
    VAx_1c = Vu(i) / cos(Vbeta(i));
    VAy_1c = (Param.Lr + Param.Lf) * Dtheta_1c / sin(Vbeta(i));
    VBxc(i) = VBx_1c * 3.6;
    VByc(i) = VBy_1c * 3.6;
    VGxc(i) = VGx_1c * 3.6;
    VGyc(i) = VGy_1c * 3.6;
    VAxc(i) = VAx_1c * 3.6;
    VAyc(i) = VAy_1c * 3.6;
    % Calcul du rayon de courbure
    R_1c = Vu(i) / Dtheta_1c;
    Rc(i) = R_1c;
    R_0c = R_1c;
    % Calcul des positions
    Bx_1c = Bx_0c + VBx_1c * cos(theta_1c + Vbeta(i)) * Param.dt;
    By_1c = By_0c + VBx_1c * sin(theta_1c + Vbeta(i)) * Param.dt;
    Gx_1c = Gx_0c + VGx_1c * cos(theta_1c + Vbeta(i)) * Param.dt;
    Gy_1c = Gy_0c + VGy_1c * sin(theta_1c + Vbeta(i)) * Param.dt;
    Ax_1c = Ax_0c + VAx_1c * cos(theta_1c + Vbeta(i) + deltaF_0) * Param.dt;
    Ay_1c = Ay_0c + VAy_1c * sin(theta_1c + Vbeta(i) + deltaF_0) * Param.dt;
    Bxc(i) = Bx_1c;
    Byc(i) = By_1c;
    Gxc(i) = Gx_1c;
    Gyc(i) = Gy_1c;
    Axc(i) = Ax_1c;
    Ayc(i) = Ay_1c;
    % Calcul des accélérations
    ABx_1c = (Vu(i) - Vu(i-1)) / Param.dt;
    ABy_1c = Vu(i) * Dtheta_1c;
    AGx_1c = -Param.Lr * Dtheta_1c^2 / sin(delta_1c);
    AGy_1c = Vu(i) * Dtheta_1c / cos(delta_1c);
    AAx_1c = -(Param.Lr + Param.Lf) * Dtheta_1c^2 / sin(Vbeta(i));
    AAy_1c = Vu(i) * Dtheta_1c / cos(Vbeta(i));
    ABxc(i) = ABx_1c / 9.81;
    AByc(i) = ABy_1c / 9.81;
    AGxc(i) = AGx_1c / 9.81;
    AGyc(i) = AGy_1c / 9.81;
    AAxc(i) = AAx_1c / 9.81;
    AAyc(i) = AAy_1c / 9.81;
    % Mise à jour des variables
    Dtheta_0c = Dtheta_1c;
    theta_0c = theta_1c;
    delta_0c = delta_1c;
    Bx_0c = Bx_1c;
    By_0c = By_1c;
    Gx_0c = Gx_1c;
    Gy_0c = Gy_1c;
    Ax_0c = Ax_1c;
    Ay_0c = Ay_1c;
    VBx_0c = VBx_1c;
    VBy_0c = VBy_1c;
    VGx_0c = VGx_1c;
    VGy_0c = VGy_1c;
    VAx_0c = VAx_1c;
    VAy_0c = VAy_1c;
    ABx_0c = ABx_1c;
    ABy_0c = ABy_1c;
    AGx_0c = AGx_1c;
    AGy_0c = AGy_1c;
    AAx_0c = AAx_1c;
    AAy_0c = AAy_1c;

    % Mise à jour des variables cinématiques
    D2theta_0c = D2theta_1;
    Dtheta_0c = Dtheta_1c;
    theta_0c = theta_1c;
    delta_0c = delta_1c;
    deltaF_0c = deltaF_1;
    deltaR_0c = deltaR_1;
    da_0c= da_1;
    Ff_0c = Ff_1;
    Fr_0c = Fr_1;
    Frmax_0c = Frmax_1;
    Ffmax_0c = Ffmax_1;
    Ax_0c = Ax_1c;
    Ay_0c = Ay_1c;
    Bx_0c = Bx_1c ;
    By_0c = By_1c ;
    Gx_0c = Gx_1c;
    Gy_0c = Gy_1c;
    R_0c = R_1c;
    VBx_0c = VBx_1c;
    VBy_0c = VBy_1c;
    VB_0c = VB_1;
    VGx_0c = VGx_1c;
    VGy_0c = VGy_1c;
    VAx_0c = VAx_1c;
    VAy_0c = VAy_1c;
    ABx_0c = ABx_1c;
    ABy_0c = ABy_1c;
    AGx_0c = AGx_1c;
    AGy_0c = AGy_1c;
    AG_0c = AG_1;
    AAx_0c = AAx_1c;
    AAy_0c = AAy_1c;

    % Mise à jour des variables
    D2theta_0 = D2theta_1;
    Dtheta_0 = Dtheta_1;
    theta_0 = theta_1;
    delta_0 = delta_1;
    deltaF_0 = deltaF_1;
    deltaR_0 = deltaR_1;
    da_0 = da_1;
    Ff_0 = Ff_1;
    Fr_0 = Fr_1;
    Frmax_0 = Frmax_1;
    Ffmax_0 = Ffmax_1;
    Ax_0 = Ax_1;
    Ay_0 = Ay_1;
    Bx_0 = Bx_1 ;
    By_0 = By_1 ;
    Gx_0 = Gx_1;
    Gy_0 = Gy_1;
    R_0 = R_1;
    VBx_0 = VBx_1;
    VBy_0 = VBy_1;
    VB_0 = VB_1;
    VGx_0 = VGx_1;
    VGy_0 = VGy_1;
    VAx_0 = VAx_1;
    VAy_0 = VAy_1;
    ABx_0 = ABx_1;
    ABy_0 = ABy_1;
    AGx_0 = AGx_1;
    AGy_0 = AGy_1;
    AG_0 = AG_1;
    AAx_0 = AAx_1;
    AAy_0 = AAy_1;
    end
    end
end