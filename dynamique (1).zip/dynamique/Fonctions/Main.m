clear all
clc
% Défininition des paramètres de simulation
scenario = 1;  % Choix du scénario
T_simu = 100;   % Durée de la simulation en secondes
vitesse = 50;  % Vitesse initiale en km/h
braquage = 5;  % Angle de braquage en degrés
tau = 0;%1/5;     % Temps de réponse à 98%

% Instance pour les paramètres d'état
Param = Param();

%Simule
%[Ax_, Ay_, Gx_, Gy_, Bx_, By_, vect_temps, delta_, Dtheta_, deltaF_, deltaR_, DA_, Ff_, Fr_, Ffmax_, Frmax_, Vu, Vbeta, beta_] = Simule(scenario, T_simu, DataVehicule, Param_etat, vitesse, braquage, tau);

[Ax, Ay, Gx, Gy, Bx, By,Axc, Ayc, Gxc, Gyc, Bxc, Byc, vect_temps, delta_,delta_c, Dtheta_,Dtheta_c, deltaF_, deltaR_, DA_, Ff_, Fr_, Ffmax_, Frmax_, Vu, Vbeta,beta_] = Simulation(scenario, T_simu, Param, vitesse, braquage, tau);

% Calcul des angles de dérive cinématiques et dynamiques
delta_cinematique = atan(Param.L * tan(beta_) ./ (Param.L + Param.Lr * tan(beta_)));
delta_dynamique = delta_;

% Calcul des vitesses angulaires cinématiques et dynamiques
Dtheta_cinematique = Vu .* tan(beta_) / Param.L;
Dtheta_dynamique = Dtheta_;

% Tracer les résultats
Tracer.tracer(Ax, Ay, Gx, Gy, Bx, By,Axc, Ayc, Gxc, Gyc, Bxc, Byc, vect_temps_, delta_, Dtheta_, deltaF_, deltaR_, DA_, Fr_, Ff_, Ffmax_, Frmax_, Vu, Vbeta, beta_,beta_c, delta_c, delta_, Dtheta_c, Dtheta_, app);

% Mettre les angles de dérives cinématiques et dynamiques sur un graphe
% Et vitesse angulaire cinématique et dynamiques sur un autre