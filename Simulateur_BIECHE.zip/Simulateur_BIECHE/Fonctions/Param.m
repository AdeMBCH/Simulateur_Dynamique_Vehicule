classdef Param
    properties
        m=1310; %Kg
        Iz=1760; %moment d'inertie lacet Kg.m^-2
        Lf=1.2; %m
        Lr=1.4; %m
        Cf=69740; %N.rad^-1
        Cr=63460; %N.rad^-1
        L=1.2+1.4; %m
        
        % Vecteurs d'état
        theta_
        Dtheta_
        D2theta_
        delta_
        Ddelta_
        deltaR_
        deltaF_
        DA_
        Ff_
        Fr_
        Ffmax_
        Frmax_
        R
        Bx_
        By_
        Gx_
        Gy_
        Ax_
        Ay_
        VBx
        VBy
        VGx
        VGy
        VAx
        VAy
        ABx
        ABy
        AGx
        AGy
        AAx
        AAy

        % parametres simulation
        tf
        dt
        Temps_
        Lt
        AngleBraquage
    end
end