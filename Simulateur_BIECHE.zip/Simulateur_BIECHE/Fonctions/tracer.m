function tracer(Ax, Ay, Gx, Gy, Bx, By,Axc, Ayc, Gxc, Gyc, Bxc, Byc, vect_temps, delta_, Dtheta_, deltaF_, deltaR_, DA_, Fr_, Ff_, Ffmax_, Frmax_, Vu, Vbeta, beta_, delta_c, Dtheta_c, app)
    cla(app.UIAxes)
    cla(app.UIAxes_1)
    cla(app.UIAxes_2)
    cla(app.UIAxes_3)
    cla(app.UIAxes_4)
    cla(app.UIAxes_5)
    cla(app.UIAxes_6)

    % Position des roues et du centre de gravité

    %A commenter pour afficher la position des roues
    plot(app.UIAxes, Gx, Gy, 'LineWidth', 0.5, 'Color', 'r');
    
    %A décommenter pour afficher la position des roues
    %plot(app.UIAxes,Ax,Ay,'b', Gx, Gy, 'r', Bx, By, 'g');
    %xlabel(app.UIAxes, 'Position en x (m)');
    %ylabel(app.UIAxes, 'Position en y (m)');


    %A commenter pour afficher la position des roues 
    title(app.UIAxes, 'Position du centre de gravité');
    legend(app.UIAxes, 'Position du centre de gravité');
    
    % A décommenter pour afficher la position des roues
    %title(app.UIAxes, 'Position des roues et du centre de gravité');
    %legend(app.UIAxes,'Position des roues avant', 'Position centre de gravité', 'Position roue arrière');

    axis(app.UIAxes, 'equal');
    grid(app.UIAxes, 'on');

    % Angle de Dérive global et vitesse angulaire Lacet
    yyaxis(app.UIAxes_1, 'left');
    plot(app.UIAxes_1, vect_temps, delta_, 'LineWidth', 0.5, 'Color', 'r');
    ylabel(app.UIAxes_1, 'Angle (deg)');
    yyaxis(app.UIAxes_1, 'right');
    plot(app.UIAxes_1, vect_temps, Dtheta_, 'LineWidth', 0.5, 'Color', 'b');
    ylabel(app.UIAxes_1, 'Vitesse Angulaire Lacet (deg/s)');
    xlabel(app.UIAxes_1, 'Temps (s)');
    title(app.UIAxes_1, 'Angle de Dérive global et vitesse angulaire Lacet');
    legend(app.UIAxes_1, 'Angle de Dérive global', 'Vitesse angulaire Lacet');

    % Différence des angles de Dérive avant et arrière
    plot(app.UIAxes_2, vect_temps, DA_, 'LineWidth', 2);
    xlabel(app.UIAxes_2, 'Temps (s)');
    ylabel(app.UIAxes_2, 'Angle (deg)');
    title(app.UIAxes_2, 'Différence des angles de Dérive avant et arrière');

    % Vitesse d'entrée et Angle de braquage
    yyaxis(app.UIAxes_3, 'left');
    plot(app.UIAxes_3, vect_temps, Vu * 3.6, 'LineWidth', 2, 'Color', 'b');
    ylabel(app.UIAxes_3, 'Vitesse (km/h)');
    yyaxis(app.UIAxes_3, 'right');
    plot(app.UIAxes_3, vect_temps, Vbeta * 180 / pi, 'LineWidth', 2, 'Color', 'r');
    ylabel(app.UIAxes_3, 'Angle de braquage (deg)');
    xlabel(app.UIAxes_3, 'Temps (s)');
    title(app.UIAxes_3, 'Vitesse d''entrée et Angle de braquage');
    legend(app.UIAxes_3, 'Vitesse d''entrée', 'Angle de braquage');

    % Force de dérive latéral avant et arrière avec saturation
    plot(app.UIAxes_4, deltaF_ * pi / 180, Ffmax_, deltaR_ * pi / 180, Frmax_, 'LineWidth', 2);
    xlabel(app.UIAxes_4, 'Angle de dérive (rad)');
    ylabel(app.UIAxes_4, 'Force de dérive latéral (N)');
    title(app.UIAxes_4, 'Force de dérive latéral avant et arrière avec saturation');
    legend(app.UIAxes_4, 'Force de dérive latéral avant', 'Force de dérive latéral arrière');

    % Angles de dérive cinématique et dynamique
    plot(app.UIAxes_5, vect_temps, delta_c, 'LineWidth', 2, 'Color', 'b');
    hold(app.UIAxes_5, 'on');
    plot(app.UIAxes_5, vect_temps, delta_, 'LineWidth', 2, 'Color', 'r');
    xlabel(app.UIAxes_5, 'Temps (s)');
    ylabel(app.UIAxes_5, 'Angle de dérive (deg)');
    title(app.UIAxes_5, 'Angles de dérive cinématique et dynamique');
    legend(app.UIAxes_5, 'Angle de dérive cinématique', 'Angle de dérive dynamique');
    grid(app.UIAxes_5, 'on');
    hold(app.UIAxes_5, 'off');

    % Vitesses angulaires cinématique et dynamique
    plot(app.UIAxes_6, vect_temps, Dtheta_c, 'LineWidth', 2, 'Color', 'b');
    hold(app.UIAxes_6, 'on');
    plot(app.UIAxes_6, vect_temps, Dtheta_, 'LineWidth', 2, 'Color', 'r');
    xlabel(app.UIAxes_6, 'Temps (s)');
    ylabel(app.UIAxes_6, 'Vitesse angulaire (deg/s)');
    title(app.UIAxes_6, 'Vitesses angulaires cinématique et dynamique');
    legend(app.UIAxes_6, 'Vitesse angulaire cinématique', 'Vitesse angulaire dynamique');
    grid(app.UIAxes_6, 'on');
    hold(app.UIAxes_6, 'off');
end