classdef Tracer
    methods (Static)
        function tracer(Ax, Ay, Gx, Gy, Bx, By, vect_temps, delta_, Dtheta_, deltaF_, deltaR_, DA_, Fr_, Ff_, Ffmax_, Frmax_, Vu, Vbeta, beta_, delta_cinematique, delta_dynamique, Dtheta_cinematique, Dtheta_dynamique)
            close all
            Tracer.tracerPosition(Ax, Ay, Gx, Gy, Bx, By)
            Tracer.tracerAngleVitesse(vect_temps, delta_, Dtheta_)
            %Tracer.tracerVitesse(vect_temps_, Vu)
            Tracer.tracerDifferenceAngles(vect_temps, DA_)
            %Tracer.tracerAngleBraquage(vect_temps_, Vbeta)
            %Tracer.tracerVitesseBraquage(vect_temps_, Vbeta)

            Tracer.tracerVitesseEtBraquage(vect_temps, Vu, beta_)
            %Tracer.tracerForcesDeriveLatrales(deltaF_, deltaR_, Ffmax_, Frmax_)

            Tracer.tracerAnglesDerives(vect_temps, delta_cinematique, delta_dynamique)
            Tracer.tracerVitessesAngulaires(vect_temps, Dtheta_cinematique, Dtheta_dynamique)
        end
        function tracerAnglesDerives(vect_temps_, delta_cinematique_, delta_dynamique_)
            figure('Name', 'Angles de dérive cinématique et dynamique');
            plot(vect_temps_, delta_cinematique_, 'LineWidth', 2, 'Color', 'b');
            hold on;
            plot(vect_temps_, delta_dynamique_, 'LineWidth', 2, 'Color', 'r');
            xlabel('Temps (s)');
            ylabel('Angle de dérive (deg)');
            title('Angles de dérive cinématique et dynamique');
            legend('Angle de dérive cinématique', 'Angle de dérive dynamique');
            grid on;
        end
    
        function tracerVitessesAngulaires(vect_temps_, Dtheta_cinematique_, Dtheta_dynamique_)
            figure('Name', 'Vitesses angulaires cinématique et dynamique');
            plot(vect_temps_, Dtheta_cinematique_, 'LineWidth', 2, 'Color', 'b');
            hold on;
            plot(vect_temps_, Dtheta_dynamique_, 'LineWidth', 2, 'Color', 'r');
            xlabel('Temps (s)');
            ylabel('Vitesse angulaire (deg/s)');
            title('Vitesses angulaires cinématique et dynamique');
            legend('Vitesse angulaire cinématique', 'Vitesse angulaire dynamique');
            grid on;
        end

        function tracerPosition(Ax_, Ay_, Gx_, Gy_, Bx_, By_)
            figure('Name', 'Position des roues et du centre de gravité');
            hold on;
            %plot(Ax_, Ay_, 'LineWidth', 0.5, 'Color', 'b');
            plot(Gx_, Gy_, 'LineWidth', 0.5, 'Color', 'r');
            %plot(Bx_, By_, 'LineWidth', 0.5, 'Color', 'g');
            % scatter(Ax_, Ay_, 50, 'b', 'filled'); % Point bleu pour la roue avant
            % scatter(Gx_, Gy_, 50, 'r', 'filled'); % Point rouge pour le centre de gravité
            % scatter(Bx_, By_, 50, 'g', 'filled'); % Point vert pour la roue arrière
 
            % text(Ax, Ay, '  A', 'VerticalAlignment', 'bottom', 'HorizontalAlignment', 'left');
            % text(Gx, Gy, '  G', 'VerticalAlignment', 'bottom', 'HorizontalAlignment', 'left');
            % text(Bx, By, '  B', 'VerticalAlignment', 'bottom', 'HorizontalAlignment', 'left');
            
            xlabel('Position en x (m)');
            ylabel('Position en y (m)');
            title('Position des roues et du centre de gravité');
            legend('Position du centre de gravité');
            axis equal;
            grid on;
        end

        function tracerAngleVitesse(vect_temps_, delta_, Dtheta_)
            figure('Name', 'Angle de Dérive global et vitesse angulaire Lacet');
            yyaxis left;
            plot(vect_temps_, delta_, 'LineWidth', 0.5, 'Color', 'r');
            ylabel('Angle (deg)');
            yyaxis right;
            plot(vect_temps_, Dtheta_, 'LineWidth', 0.5, 'Color', 'b');
            ylabel('Vitesse Angulaire Lacet (deg/s)');
            xlabel('Temps (s)');
            title('Angle de Dérive global et vitesse angulaire Lacet');
            legend('Angle de Dérive global', 'Vitesse angulaire Lacet');
        end

        function tracerVitesse(vect_temps_, Vu)
            figure('Name', 'Vitesse d''entrée');
            plot(vect_temps_, Vu * 3.6, 'LineWidth', 2);
            xlabel('Temps (s)');
            ylabel('Vitesse (km/h)');
            title('Vitesse d''entrée');
        end

        function tracerDifferenceAngles(vect_temps_, DA_)
            figure('Name', 'Différence des angles de Dérive avant et arrière');
            plot(vect_temps_, DA_, 'LineWidth', 2);
            xlabel('Temps (s)');
            ylabel('Angle (deg)');
            title('Différence des angles de Dérive avant et arrière');
        end

        function tracerVitesseBraquage(vect_temps_, Vbeta)
            figure('Name', 'Vitesse de braquage en entrée');
            plot(vect_temps_, Vbeta * 180 / pi, 'LineWidth', 2);
            xlabel('Temps (s)');
            ylabel('Angle de braquage (deg)');
            title('Angle de braquage en entrée');
        end

         function tracerAngleBraquage(vect_temps_, beta_)
            figure('Name', 'Angle de braquage en entrée');
            plot(vect_temps_, beta_ * 180 / pi, 'LineWidth', 2);
            xlabel('Temps (s)');
            ylabel('Angle de braquage (deg)');
            title('Angle de braquage en entrée');
        end

        function tracerForcesDeriveLatrales(deltaF_, deltaR_, Ffmax_, Frmax_)
            figure('Name', 'Force de dérive latéral avant et arrière avec saturation');
            plot(deltaF_ * pi / 180, Ffmax_, deltaR_ * pi / 180, Frmax_, 'LineWidth', 2);
            xlabel('Angle de dérive (rad)');
            ylabel('Force de dérive latéral (N)');
            title('Force de dérive latéral avant et arrière');
            legend('Force de dérive latéral avant', 'Force de dérive latéral arrière');
        end

        function tracerVitesseEtBraquage(vect_temps_, Vu, beta_)
            figure('Name', 'Vitesse d''entrée et Angle de braquage');
            
            % Subplot pour la vitesse
            subplot(2,1,1);
            plot(vect_temps_, Vu * 3.6, 'LineWidth', 2, 'Color', 'b');
            ylabel('Vitesse (km/h)');
            title('Vitesse d''entrée');
            grid on;
            
            % Subplot pour l'angle de braquage
            subplot(2,1,2);
            plot(vect_temps_, beta_ * 180 / pi, 'LineWidth', 2, 'Color', 'r');
            ylabel('Angle de braquage (deg)');
            xlabel('Temps (s)');
            title('Angle de braquage en entrée');
            grid on;

            sgtitle('Vitesse d''entrée et Angle de braquage');
        end
    end
end